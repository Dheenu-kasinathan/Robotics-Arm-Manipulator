# Matlab/Octave test

Script made for Matlab/Octave in order to test the discretizing method for the path.